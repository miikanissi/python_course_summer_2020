import random
lotto = []
for i in range(7):
    lotto.append(random.randint(1,40))

print("7 number lotto: ", lotto)
