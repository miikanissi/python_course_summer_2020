a = 999999 # integer
b = 5.555555555555 # float
c = 'x' # string
d = "Kokkola" # string
e = 2.33 # float
f = 10 # integer
g = 300 # integer
h = 9000000000 # integer
i = 3000000000 # integer

print(type(a))
print(type(b))
print(type(c))
print(type(d))
print(type(e))
print(type(f))
print(type(g))
print(type(h))
print(type(i))
