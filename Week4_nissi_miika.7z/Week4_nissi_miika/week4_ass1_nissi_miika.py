print("Sum of values 1-5 using for loop")
sum1 = 0
for x in range(1,6):
    sum1 += x
print(sum1)

print("Sum of values 1-5 using while loop")
x = 1
sum2 = 0
while x < 6:
    sum2 += x
    x += 1
print(sum2)
