def sums(array):
    return sum(array)

arr = [10,5,7,3]
print(sums(arr))
