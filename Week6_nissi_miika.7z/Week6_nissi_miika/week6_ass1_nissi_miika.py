def average(x, y):
    avg = (x + y)/2
    return avg

print(average(10,20))
print(average(1,2))
