def average(x,y,z,a):
    avg = (x + y + z + a)/4
    return avg

print(average(10,20,30.49,9.9))
