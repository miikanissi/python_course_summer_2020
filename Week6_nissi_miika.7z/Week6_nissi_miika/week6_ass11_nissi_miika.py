def sqrt(n):
    if n < 0:
        return
    else:
        return n**0.5

print(sqrt(2))
