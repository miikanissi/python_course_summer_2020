def bmi(height, weight):
    x = weight/(height * height)
    return x

print(bmi(1.75, 100))
