def biggest(a,b,c,d,e):
    return max(a,b,c,d,e)

print(biggest(3,6,8,2,10))
